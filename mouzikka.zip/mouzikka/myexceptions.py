import random








class NoSongSelectedError(Exception):
    pass