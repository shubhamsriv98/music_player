import cx_Oracle
conn=None
try:
	conn=cx_Oracle.connect("scott/tiger@127.0.0.1/orcl")
	print("Connected successfully to the DB")
	print("Oracle version is ",conn.version)
	print("Username is ",conn.username)
except (cx_Oracle.DatabaseError)as ex:
	print("Error in connecting to Oracle:",ex)
finally:
		if conn is not None:
			conn.close()
			print("Disconnected successfully from the DB")
